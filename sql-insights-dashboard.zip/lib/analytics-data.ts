export type Region = "all" | "north-america" | "europe" | "asia-pacific" | "latin-america"
export type Category = "all" | "electronics" | "apparel" | "home" | "beauty" | "sports"
export type DateRange = "7d" | "30d" | "90d" | "12m"

export const REGIONS: { value: Region; label: string }[] = [
  { value: "all", label: "All Regions" },
  { value: "north-america", label: "North America" },
  { value: "europe", label: "Europe" },
  { value: "asia-pacific", label: "Asia Pacific" },
  { value: "latin-america", label: "Latin America" },
]

export const CATEGORIES: { value: Category; label: string }[] = [
  { value: "all", label: "All Categories" },
  { value: "electronics", label: "Electronics" },
  { value: "apparel", label: "Apparel" },
  { value: "home", label: "Home & Living" },
  { value: "beauty", label: "Beauty" },
  { value: "sports", label: "Sports" },
]

export const DATE_RANGES: { value: DateRange; label: string }[] = [
  { value: "7d", label: "Last 7 days" },
  { value: "30d", label: "Last 30 days" },
  { value: "90d", label: "Last 90 days" },
  { value: "12m", label: "Last 12 months" },
]

export type Filters = {
  dateRange: DateRange
  region: Region
  category: Category
}

// Deterministic pseudo-random generator so charts are stable across renders
function seeded(seed: number) {
  let s = seed
  return () => {
    s = (s * 9301 + 49297) % 233280
    return s / 233280
  }
}

// Multipliers used to make filters meaningfully change the numbers
const regionFactor: Record<Region, number> = {
  all: 1,
  "north-america": 0.42,
  europe: 0.3,
  "asia-pacific": 0.21,
  "latin-america": 0.07,
}

const categoryFactor: Record<Category, number> = {
  all: 1,
  electronics: 0.38,
  apparel: 0.24,
  home: 0.18,
  beauty: 0.12,
  sports: 0.08,
}

const rangePoints: Record<DateRange, number> = {
  "7d": 7,
  "30d": 30,
  "90d": 90,
  "12m": 12,
}

function scale(filters: Filters) {
  return regionFactor[filters.region] * categoryFactor[filters.category]
}

export type Kpi = {
  label: string
  value: string
  rawValue: number
  delta: number
  positive: boolean
  format: "currency" | "number" | "percent"
}

export function getKpis(filters: Filters): Kpi[] {
  const f = scale(filters)
  const rand = seeded(
    filters.dateRange.length * 31 + filters.region.length * 7 + filters.category.length * 13,
  )
  const revenue = Math.round(4820000 * f * (0.92 + rand() * 0.2))
  const orders = Math.round(38420 * f * (0.9 + rand() * 0.2))
  const retention = 62 + Math.round(rand() * 22)
  const aov = revenue / Math.max(orders, 1)

  return [
    {
      label: "Total Revenue",
      value: formatCurrency(revenue),
      rawValue: revenue,
      delta: 12.4 + rand() * 6,
      positive: true,
      format: "currency",
    },
    {
      label: "Total Orders",
      value: orders.toLocaleString("en-US"),
      rawValue: orders,
      delta: 8.1 + rand() * 4,
      positive: true,
      format: "number",
    },
    {
      label: "Customer Retention",
      value: `${retention}%`,
      rawValue: retention,
      delta: rand() > 0.5 ? 3.2 : -2.1,
      positive: rand() > 0.35,
      format: "percent",
    },
    {
      label: "Avg. Order Value",
      value: formatCurrency(Math.round(aov)),
      rawValue: Math.round(aov),
      delta: 4.6 + rand() * 3,
      positive: true,
      format: "currency",
    },
  ]
}

export type SalesPoint = { label: string; revenue: number; orders: number }

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

export function getSalesTrend(filters: Filters): SalesPoint[] {
  const f = scale(filters)
  const n = rangePoints[filters.dateRange]
  const rand = seeded(filters.region.length * 17 + filters.category.length * 23 + n)
  const base = (filters.dateRange === "12m" ? 410000 : 14000) * f

  return Array.from({ length: n }, (_, i) => {
    const trend = 1 + (i / n) * 0.35
    const noise = 0.78 + rand() * 0.44
    const revenue = Math.round(base * trend * noise)
    const label =
      filters.dateRange === "12m"
        ? MONTHS[i % 12]
        : filters.dateRange === "7d"
          ? `Day ${i + 1}`
          : `${i + 1}`
    return { label, revenue, orders: Math.round(revenue / 126) }
  })
}

export type ProductRow = { name: string; revenue: number; units: number }

const PRODUCTS = [
  "Aurora Wireless Buds",
  "Nimbus Smartwatch",
  "Vertex Laptop Stand",
  "Lumen Desk Lamp",
  "Pulse Fitness Band",
  "Echo Noise Headset",
  "Terra Travel Backpack",
  "Cobalt Mechanical Keyboard",
]

export function getTopProducts(filters: Filters): ProductRow[] {
  const f = scale(filters)
  const rand = seeded(filters.category.length * 41 + filters.region.length * 11)
  return PRODUCTS.map((name) => ({
    name,
    revenue: Math.round(320000 * f * (0.4 + rand())),
    units: Math.round(2400 * f * (0.4 + rand())),
  }))
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 6)
}

export type CategorySlice = { name: string; value: number; key: string }

export function getCategoryRevenue(filters: Filters): CategorySlice[] {
  const f = regionFactor[filters.region]
  const rand = seeded(filters.region.length * 53 + 7)
  const cats =
    filters.category === "all"
      ? CATEGORIES.filter((c) => c.value !== "all")
      : CATEGORIES.filter((c) => c.value === filters.category)
  return cats.map((c) => ({
    name: c.label,
    key: c.value,
    value: Math.round(980000 * f * categoryFactor[c.value as Category] * (0.7 + rand() * 0.6)),
  }))
}

export type Segment = { name: string; value: number; key: string }

export function getCustomerSegments(filters: Filters): Segment[] {
  const rand = seeded(filters.region.length * 19 + filters.category.length * 3)
  const champions = 18 + Math.round(rand() * 6)
  const loyal = 24 + Math.round(rand() * 6)
  const potential = 20 + Math.round(rand() * 6)
  const atRisk = 16 + Math.round(rand() * 5)
  const churned = Math.max(100 - champions - loyal - potential - atRisk, 6)
  return [
    { name: "Champions", key: "champions", value: champions },
    { name: "Loyal", key: "loyal", value: loyal },
    { name: "Potential", key: "potential", value: potential },
    { name: "At Risk", key: "at-risk", value: atRisk },
    { name: "Churned", key: "churned", value: churned },
  ]
}

export type Insight = {
  title: string
  body: string
  recommendation: string
  impact: "high" | "medium" | "low"
}

export function getInsights(filters: Filters): Insight[] {
  const kpis = getKpis(filters)
  const segments = getCustomerSegments(filters)
  const products = getTopProducts(filters)
  const retention = kpis[2].rawValue
  const topProduct = products[0]
  const atRisk = segments.find((s) => s.key === "at-risk")?.value ?? 0

  const regionLabel = REGIONS.find((r) => r.value === filters.region)?.label ?? "all regions"
  const categoryLabel = CATEGORIES.find((c) => c.value === filters.category)?.label ?? "all categories"

  return [
    {
      title: "Revenue momentum is accelerating",
      body: `Revenue for ${regionLabel} is up ${kpis[0].delta.toFixed(1)}% versus the prior period, outpacing order growth of ${kpis[1].delta.toFixed(1)}% — indicating higher basket sizes.`,
      recommendation: "Double down on bundle offers and free-shipping thresholds to push average order value higher.",
      impact: "high",
    },
    {
      title: `${topProduct.name} is your growth engine`,
      body: `${topProduct.name} drives ${formatCurrency(topProduct.revenue)} in ${categoryLabel} revenue, the single largest contributor this period.`,
      recommendation: "Feature it in homepage hero placements and allocate more ad spend to its best-converting keywords.",
      impact: "medium",
    },
    {
      title: `${atRisk}% of customers are slipping toward churn`,
      body: `Retention is sitting at ${retention}%, while the "At Risk" segment makes up ${atRisk}% of your base — a measurable revenue threat next quarter.`,
      recommendation: "Trigger a win-back email sequence with a personalized discount for customers inactive 45+ days.",
      impact: retention < 70 ? "high" : "medium",
    },
  ]
}

export function formatCurrency(value: number): string {
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(2)}M`
  if (value >= 1_000) return `$${(value / 1_000).toFixed(1)}K`
  return `$${value.toLocaleString("en-US")}`
}
