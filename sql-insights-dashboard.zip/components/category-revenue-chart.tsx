"use client"

import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { formatCurrency, type CategorySlice } from "@/lib/analytics-data"

export function CategoryRevenueChart({ data }: { data: CategorySlice[] }) {
  const total = data.reduce((s, d) => s + d.value, 0)
  const config = Object.fromEntries(
    data.map((d, i) => [d.key, { label: d.name, color: `var(--chart-${(i % 5) + 1})` }]),
  )

  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="text-base">Category-wise Revenue</CardTitle>
        <CardDescription>Share of total revenue by category</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center gap-4 sm:flex-row">
          <ChartContainer config={config} className="aspect-square h-[200px]">
            <ResponsiveContainer>
              <PieChart>
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      hideLabel
                      formatter={(value, name) => (
                        <span className="flex w-full justify-between gap-3">
                          <span className="text-muted-foreground">{config[name as string]?.label ?? name}</span>
                          <span className="font-medium tabular-nums">{formatCurrency(value as number)}</span>
                        </span>
                      )}
                    />
                  }
                />
                <Pie
                  data={data}
                  dataKey="value"
                  nameKey="key"
                  innerRadius={52}
                  outerRadius={88}
                  paddingAngle={2}
                  strokeWidth={0}
                >
                  {data.map((_, i) => (
                    <Cell key={i} fill={`var(--chart-${(i % 5) + 1})`} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </ChartContainer>

          <ul className="flex w-full flex-col gap-2.5">
            {data.map((d, i) => (
              <li key={d.key} className="flex items-center justify-between gap-2 text-sm">
                <span className="flex items-center gap-2">
                  <span
                    className="size-2.5 rounded-sm"
                    style={{ background: `var(--chart-${(i % 5) + 1})` }}
                  />
                  <span className="text-muted-foreground">{d.name}</span>
                </span>
                <span className="font-medium tabular-nums">
                  {total ? Math.round((d.value / total) * 100) : 0}%
                </span>
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}
