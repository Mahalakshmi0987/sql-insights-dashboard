"use client"

import { Lightbulb, Sparkles, TrendingUp } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { Insight } from "@/lib/analytics-data"

const impactStyles: Record<Insight["impact"], string> = {
  high: "bg-destructive/15 text-destructive border-destructive/20",
  medium: "bg-chart-3/15 text-chart-3 border-chart-3/20",
  low: "bg-chart-2/15 text-chart-2 border-chart-2/20",
}

export function AiInsightsPanel({ insights }: { insights: Insight[] }) {
  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Sparkles className="size-4" />
            </span>
            <div>
              <CardTitle className="text-base">AI Business Insights</CardTitle>
              <CardDescription className="text-xs">Generated from your current filters</CardDescription>
            </div>
          </div>
          <Badge variant="secondary" className="gap-1 text-xs">
            <span className="size-1.5 animate-pulse rounded-full bg-chart-4" />
            Auto
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        {insights.map((insight, i) => (
          <div
            key={insight.title}
            className="animate-fade-up rounded-lg border border-border bg-background/40 p-4"
            style={{ animationDelay: `${i * 90}ms` }}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <TrendingUp className="size-4 shrink-0 text-primary" />
                <p className="text-sm font-medium leading-tight text-pretty">{insight.title}</p>
              </div>
              <span
                className={`shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide ${impactStyles[insight.impact]}`}
              >
                {insight.impact}
              </span>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground text-pretty">{insight.body}</p>
            <div className="mt-3 flex items-start gap-2 rounded-md bg-accent/60 p-2.5 text-xs text-accent-foreground">
              <Lightbulb className="mt-0.5 size-3.5 shrink-0" />
              <span className="leading-relaxed text-pretty">{insight.recommendation}</span>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
