"use client"

import { ArrowDownRight, ArrowUpRight, DollarSign, Package, Repeat, ShoppingCart } from "lucide-react"
import { Card } from "@/components/ui/card"
import type { Kpi } from "@/lib/analytics-data"

const ICONS = [DollarSign, ShoppingCart, Repeat, Package]

export function KpiCards({ kpis }: { kpis: Kpi[] }) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {kpis.map((kpi, i) => {
        const Icon = ICONS[i] ?? DollarSign
        return (
          <Card
            key={kpi.label}
            className="animate-fade-up gap-0 border-border bg-card p-5"
            style={{ animationDelay: `${i * 70}ms` }}
          >
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{kpi.label}</span>
              <span className="flex size-9 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                <Icon className="size-4" />
              </span>
            </div>
            <div className="mt-4 flex items-end justify-between">
              <span className="text-3xl font-semibold tracking-tight tabular-nums">{kpi.value}</span>
            </div>
            <div className="mt-3 flex items-center gap-1.5 text-xs">
              <span
                className={`flex items-center gap-0.5 rounded-md px-1.5 py-0.5 font-medium ${
                  kpi.positive
                    ? "bg-chart-4/15 text-chart-4"
                    : "bg-destructive/15 text-destructive"
                }`}
              >
                {kpi.positive ? <ArrowUpRight className="size-3" /> : <ArrowDownRight className="size-3" />}
                {Math.abs(kpi.delta).toFixed(1)}%
              </span>
              <span className="text-muted-foreground">vs previous period</span>
            </div>
          </Card>
        )
      })}
    </div>
  )
}
