"use client"

import { CalendarDays, Globe, Tag } from "lucide-react"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  type Filters,
  type DateRange,
  type Region,
  type Category,
  DATE_RANGES,
  REGIONS,
  CATEGORIES,
} from "@/lib/analytics-data"

export function FilterBar({
  filters,
  onChange,
}: {
  filters: Filters
  onChange: (f: Filters) => void
}) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
      <FilterSelect
        icon={<CalendarDays className="size-4 text-muted-foreground" />}
        value={filters.dateRange}
        onValueChange={(v) => onChange({ ...filters, dateRange: v as DateRange })}
        options={DATE_RANGES}
        ariaLabel="Date range"
      />
      <FilterSelect
        icon={<Globe className="size-4 text-muted-foreground" />}
        value={filters.region}
        onValueChange={(v) => onChange({ ...filters, region: v as Region })}
        options={REGIONS}
        ariaLabel="Region"
      />
      <FilterSelect
        icon={<Tag className="size-4 text-muted-foreground" />}
        value={filters.category}
        onValueChange={(v) => onChange({ ...filters, category: v as Category })}
        options={CATEGORIES}
        ariaLabel="Category"
      />
    </div>
  )
}

function FilterSelect({
  icon,
  value,
  onValueChange,
  options,
  ariaLabel,
}: {
  icon: React.ReactNode
  value: string
  onValueChange: (v: string) => void
  options: { value: string; label: string }[]
  ariaLabel: string
}) {
  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger
        aria-label={ariaLabel}
        className="h-10 w-full gap-2 border-border bg-card sm:w-[180px]"
      >
        {icon}
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {options.map((o) => (
          <SelectItem key={o.value} value={o.value}>
            {o.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
