"use client"

import { Database, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"

export function DashboardHeader({ onRefresh }: { onRefresh?: () => void }) {
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Database className="size-5" />
          </div>
          <div className="leading-tight">
            <p className="text-sm font-semibold tracking-tight">Helix Insights</p>
            <p className="text-xs text-muted-foreground">SQL Business Analytics</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="hidden items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs text-muted-foreground sm:flex">
            <span className="size-2 animate-pulse rounded-full bg-chart-4" />
            Live · synced 2m ago
          </span>
          <Button
            variant="outline"
            size="icon"
            aria-label="Refresh data"
            onClick={onRefresh}
            className="border-border bg-card"
          >
            <RefreshCw className="size-4" />
          </Button>
          <ThemeToggle />
        </div>
      </div>
    </header>
  )
}
