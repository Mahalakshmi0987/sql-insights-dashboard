"use client"

import { useMemo, useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { FilterBar } from "@/components/filter-bar"
import { KpiCards } from "@/components/kpi-cards"
import { SalesTrendChart } from "@/components/sales-trend-chart"
import { TopProductsChart } from "@/components/top-products-chart"
import { CategoryRevenueChart } from "@/components/category-revenue-chart"
import { CustomerSegmentsChart } from "@/components/customer-segments-chart"
import { AiInsightsPanel } from "@/components/ai-insights-panel"
import {
  type Filters,
  getKpis,
  getSalesTrend,
  getTopProducts,
  getCategoryRevenue,
  getCustomerSegments,
  getInsights,
} from "@/lib/analytics-data"

export function Dashboard() {
  const [filters, setFilters] = useState<Filters>({
    dateRange: "12m",
    region: "all",
    category: "all",
  })
  const [nonce, setNonce] = useState(0)

  const data = useMemo(() => {
    void nonce
    return {
      kpis: getKpis(filters),
      sales: getSalesTrend(filters),
      products: getTopProducts(filters),
      categories: getCategoryRevenue(filters),
      segments: getCustomerSegments(filters),
      insights: getInsights(filters),
    }
  }, [filters, nonce])

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader onRefresh={() => setNonce((n) => n + 1)} />

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-balance">Business Overview</h1>
            <p className="mt-1 text-sm text-muted-foreground text-pretty">
              Real-time analytics synthesized from your SQL warehouse.
            </p>
          </div>
          <FilterBar filters={filters} onChange={setFilters} />
        </div>

        <div className="mt-6">
          <KpiCards kpis={data.kpis} />
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <SalesTrendChart data={data.sales} />
          </div>
          <div className="lg:col-span-1">
            <CategoryRevenueChart data={data.categories} />
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2 flex flex-col gap-4">
            <TopProductsChart data={data.products} />
            <CustomerSegmentsChart data={data.segments} />
          </div>
          <div className="lg:col-span-1">
            <AiInsightsPanel insights={data.insights} />
          </div>
        </div>
      </main>
    </div>
  )
}
